=== Simple Page Title ===
	Contributors: Saurabh Jain
	Donate link: https://github.com/saurabh-developer
	Tags: Page Title, Change Page Titles
	Requires at least: 3.8
	Tested up to: 4.7
	Stable tag: 1.5
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html

	Awsome Plugin for change the page title.

== Description ==

Simple Page Title is awsome plugin for use the change of title like home page, 404 page, search page, blog page, all archieve page, all single page and category and tags.



<br />


<strong>Plugin Features</strong><br />

* Use via function.
* Use via short code.
* Change the page titles name.
* change the page titles like, Home page, 404 Page, Search Page, Blog Page, All Archieve, all SIngle post and category and tags.
* Change the heading html, class, and ID. 






== Installation ==

1. Install as regular WordPress plugin.<br />
2. Go your plugin setting via WordPress Dashboard and find "<strong>Simple Page Title</strong>" activate it.<br />

After activate plugin you will see "Simple Page Title" menu at left side on WordPress Setting Option dashboard<br />

<br />
<strong>How to display Simple Page Title ?</strong><br />

use this short-code any where to display Page titles
Short Code - `[simple_page_title]` and function simple_page_title();.






== Screenshots ==

1. screenshot-1
2. screenshot-2
3. screenshot-3
4. screenshot-4
4. screenshot-5



== Changelog ==


	= 2.0 =
    * 9/04/2017 Initial release.
