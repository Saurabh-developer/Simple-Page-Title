<?php
// Delete Option for default pages and archieve and single post.. 
delete_option('spt_home');
delete_option('spt_404');
delete_option('spt_search');
delete_option('spt_blog');
delete_option('spt_category');
delete_option('spt_tag');
delete_option('spt_blog_single');
delete_option('spt_ele_name');
delete_option('spt_ele_ID');
delete_option('spt_ele_class');
$args = array('public'=> true,'_builtin'=>false); 
$output = 'names'; 
$operator = 'and'; 
$post_types = get_post_types( $args, $output, $operator ); 
foreach ($post_types as $post_type) {
  delete_option('spta_'.$post_type.'');
  delete_option('spts_'.$post_type.''); 
} 
?>