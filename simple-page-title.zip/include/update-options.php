<?php 
 update_option('spt_home', $_POST['spt_home']);
 update_option('spt_404', $_POST['spt_404']);
 update_option('spt_search', $_POST['spt_search']);
 update_option('spt_blog', $_POST['spt_blog']);
 update_option('spt_category', $_POST['spt_category']);
 update_option('spt_tag', $_POST['spt_tag']);
 update_option('spt_blog_single', $_POST['spt_blog_single']);

 update_option('spt_ele_name', $_POST['spt_ele_name']);
 update_option('spt_ele_ID', $_POST['spt_ele_ID']);
 update_option('spt_ele_class', $_POST['spt_ele_class']);
 
 $args = array('public'=> true,'_builtin'=>false); 
 $output = 'names'; 
 $operator = 'and'; 
 $post_types = get_post_types( $args, $output, $operator ); 
 foreach ($post_types as $post_type) {
   update_option('spta_'.$post_type.'', $_POST['spta_'.$post_type.'']);
   update_option('spts_'.$post_type.'', $_POST['spts_'.$post_type.'']);
 }
?>