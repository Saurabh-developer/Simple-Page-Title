<?php
// Name options for default pages and archieve and single post.. 
  $spt_home = get_option('spt_home');
  $spt_404 = get_option('spt_404');
  $spt_search = get_option('spt_search');
  $spt_blog = get_option('spt_blog');
  $spt_category = get_option('spt_category');
  $spt_tag = get_option('spt_tag');
  $spt_blog_single = get_option('spt_blog_single');
  $spt_ele_name = get_option('spt_ele_name');
  $spt_ele_ID = get_option('spt_ele_ID');
  $spt_ele_class = get_option('spt_ele_class');
?>