<?php 
// Add Option for default pages and archieve and single post..
add_option('spt_home','Home');
add_option('spt_404','404');
add_option('spt_search','Search');
add_option('spt_blog','Blog');
add_option('spt_category','Category'); 
add_option('spt_tag','Tag');
add_option('spt_blog_single','%postname%');
add_option('spt_ele_name','h1');
add_option('spt_ele_ID','%postID%');
add_option('spt_ele_class','%postclass%');
$args = array('public'=> true,'_builtin'=>false); 
$output = 'names'; 
$operator = 'and'; 
$post_types = get_post_types( $args, $output, $operator ); 
foreach ($post_types as $post_type) {
   add_option('spta_'.$post_type.'', $post_type);
   add_option('spts_'.$post_type.'', '%postname%'); 
} 
?>